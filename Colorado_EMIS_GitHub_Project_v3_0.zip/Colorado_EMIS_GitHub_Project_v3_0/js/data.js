const DEMO_DATA = {
  fires: [
    {
      id: "fire-001",
      type: "fire",
      name: "Example Colorado Fire",
      lat: 39.7392,
      lon: -104.9903,
      status: "VERIFY",
      acres: 0,
      county: "Denver",
      notes: "Replace with verified NIFC/InciWeb/DFPC incident data."
    }
  ],
  bases: [
    {
      id: "base-001",
      type: "base",
      name: "Buckley Space Force Base",
      lat: 39.7017,
      lon: -104.7517,
      status: "Open",
      branch: "Space Force / Air National Guard",
      notes: "Coordinate exact points internally before operational use."
    },
    {
      id: "base-002",
      type: "base",
      name: "Fort Carson",
      lat: 38.7375,
      lon: -104.7889,
      status: "Open",
      branch: "Army",
      notes: "Sample installation marker."
    }
  ],
  efacs: [
    {
      id: "efac-001",
      type: "efac",
      name: "E-FAC Placeholder",
      lat: 39.5501,
      lon: -105.7821,
      status: "Planned",
      phone: "",
      notes: "Add real emergency family assistance center information."
    }
  ],
  shelters: [
    {
      id: "shelter-001",
      type: "shelter",
      name: "Shelter Placeholder",
      lat: 38.8339,
      lon: -104.8214,
      status: "Standby",
      capacity: 0,
      pets: "Unknown",
      notes: "Add verified shelter location and capacity."
    }
  ],
  pois: [
    {
      id: "poi-001",
      type: "poi",
      name: "Colorado State EOC Placeholder",
      lat: 39.7392,
      lon: -104.9903,
      status: "Reference",
      category: "Emergency Management",
      notes: "Update with verified official facility point."
    }
  ],
  roads: [
    {
      id: "road-001",
      type: "road",
      name: "Road Closure Placeholder",
      lat: 39.0,
      lon: -105.5,
      status: "Inactive",
      notes: "Use for route closure or checkpoint marker."
    }
  ]
};
