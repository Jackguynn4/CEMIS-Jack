let map;
let layerGroups = {};
let appData = {};

const iconColors = {
  fires: "red",
  bases: "blue",
  efacs: "green",
  shelters: "violet",
  pois: "orange",
  roads: "black"
};

function initMap() {
  map = L.map("map").setView([39.5501, -105.7821], 7);

  const topo = L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
    maxZoom: 19,
    attribution: "&copy; OpenStreetMap contributors"
  }).addTo(map);

  const esriImagery = L.tileLayer(
    "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
    {
      maxZoom: 19,
      attribution: "Tiles &copy; Esri"
    }
  );

  const esriTopo = L.tileLayer(
    "https://server.arcgisonline.com/ArcGIS/rest/services/World_Topo_Map/MapServer/tile/{z}/{y}/{x}",
    {
      maxZoom: 19,
      attribution: "Tiles &copy; Esri"
    }
  );

  layerGroups = {
    fires: L.layerGroup().addTo(map),
    bases: L.layerGroup().addTo(map),
    efacs: L.layerGroup().addTo(map),
    shelters: L.layerGroup().addTo(map),
    pois: L.layerGroup().addTo(map),
    roads: L.layerGroup().addTo(map)
  };

  L.control.layers(
    {
      "OpenStreetMap": topo,
      "Esri Imagery": esriImagery,
      "Esri Topographic": esriTopo
    },
    layerGroups,
    { collapsed: true }
  ).addTo(map);
}

function renderMap() {
  Object.values(layerGroups).forEach(group => group.clearLayers());

  Object.keys(layerGroups).forEach(layerKey => {
    const items = appData[layerKey] || [];
    items.forEach(item => addMarkerToLayer(layerKey, item));
  });

  updateSummary();
}

function addMarkerToLayer(layerKey, item) {
  if (!item.lat || !item.lon) return;

  const marker = L.circleMarker([item.lat, item.lon], {
    radius: layerKey === "fires" ? 9 : 7,
    color: iconColors[layerKey] || "white",
    fillColor: iconColors[layerKey] || "white",
    fillOpacity: 0.85,
    weight: 2
  });

  marker.bindPopup(makePopup(item));
  marker.on("click", () => showSelectedFeature(item));
  marker.addTo(layerGroups[layerKey]);
}

function makePopup(item) {
  return `
    <strong>${item.name || "Unnamed"}</strong><br>
    <span>Status: ${item.status || "Unknown"}</span><br>
    <span>Type: ${item.type || "Unknown"}</span><br>
    <span>Lat/Lon: ${item.lat}, ${item.lon}</span><br>
    <span>${item.notes || ""}</span>
  `;
}

function toggleLayer(layerKey, visible) {
  if (!layerGroups[layerKey]) return;
  if (visible) {
    map.addLayer(layerGroups[layerKey]);
  } else {
    map.removeLayer(layerGroups[layerKey]);
  }
}
