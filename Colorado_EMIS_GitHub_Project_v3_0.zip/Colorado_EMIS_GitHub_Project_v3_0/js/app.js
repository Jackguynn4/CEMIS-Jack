const STORAGE_KEY = "colorado_emis_cop_v3";

document.addEventListener("DOMContentLoaded", () => {
  document.getElementById("currentDate").textContent = new Date().toLocaleString();
  initMap();
  loadData();
  renderMap();
});

function loadData() {
  const saved = localStorage.getItem(STORAGE_KEY);
  appData = saved ? JSON.parse(saved) : structuredClone(DEMO_DATA);
}

function saveData() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(appData));
}

function resetDemoData() {
  if (!confirm("Reset all local data back to demo data?")) return;
  appData = structuredClone(DEMO_DATA);
  saveData();
  renderMap();
}

function layerKeyFromType(type) {
  return {
    fire: "fires",
    base: "bases",
    efac: "efacs",
    shelter: "shelters",
    poi: "pois",
    road: "roads"
  }[type];
}

function addPoint(type) {
  const layerKey = layerKeyFromType(type);
  if (!layerKey) return;

  const name = prompt("Name:");
  if (!name) return;

  const lat = parseFloat(prompt("Latitude, example 39.7392:"));
  const lon = parseFloat(prompt("Longitude, example -104.9903:"));

  if (Number.isNaN(lat) || Number.isNaN(lon)) {
    alert("Invalid latitude or longitude.");
    return;
  }

  const status = prompt("Status:", "VERIFY") || "VERIFY";
  const notes = prompt("Notes:", "") || "";

  const item = {
    id: `${type}-${Date.now()}`,
    type,
    name,
    lat,
    lon,
    status,
    notes
  };

  appData[layerKey].push(item);
  saveData();
  renderMap();
}

function showSelectedFeature(item) {
  const el = document.getElementById("selectedFeature");
  el.innerHTML = Object.entries(item)
    .map(([k, v]) => `<div class="feature-row"><strong>${k}</strong>: ${v}</div>`)
    .join("");
}

function updateSummary() {
  const summary = document.getElementById("summary");
  summary.innerHTML = `
    <p><span class="badge">${appData.fires.length}</span> Fires</p>
    <p><span class="badge">${appData.bases.length}</span> Bases</p>
    <p><span class="badge">${appData.efacs.length}</span> E-FACs</p>
    <p><span class="badge">${appData.shelters.length}</span> Shelters</p>
    <p><span class="badge">${appData.pois.length}</span> POIs</p>
    <p><span class="badge">${appData.roads.length}</span> Road Closures</p>
  `;
}

function exportJSON() {
  const blob = new Blob([JSON.stringify(appData, null, 2)], { type: "application/json" });
  downloadBlob(blob, "colorado_emis_data.json");
}

function importJSON(event) {
  const file = event.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = e => {
    try {
      appData = JSON.parse(e.target.result);
      saveData();
      renderMap();
      alert("Data imported.");
    } catch {
      alert("Invalid JSON file.");
    }
  };
  reader.readAsText(file);
}

function exportCSV() {
  const rows = [["layer","id","type","name","lat","lon","status","notes"]];
  Object.keys(appData).forEach(layer => {
    appData[layer].forEach(item => {
      rows.push([
        layer,
        item.id || "",
        item.type || "",
        item.name || "",
        item.lat || "",
        item.lon || "",
        item.status || "",
        (item.notes || "").replaceAll(",", " ")
      ]);
    });
  });

  const csv = rows.map(r => r.join(",")).join("\n");
  const blob = new Blob([csv], { type: "text/csv" });
  downloadBlob(blob, "colorado_emis_export.csv");
}

function generateSITREP() {
  const date = new Date().toLocaleString();
  const text = `
COLORADO EMIS SITREP
Generated: ${date}

1. OPERATIONAL SUMMARY
- Fires tracked: ${appData.fires.length}
- Military bases tracked: ${appData.bases.length}
- E-FAC points tracked: ${appData.efacs.length}
- Shelters tracked: ${appData.shelters.length}
- Points of interest tracked: ${appData.pois.length}
- Road closures tracked: ${appData.roads.length}

2. ACTIVE / RECENT FIRES
${appData.fires.map(f => `- ${f.name}: ${f.status}; ${f.notes || ""}`).join("\n")}

3. SUPPORT LOCATIONS
${appData.bases.map(b => `- ${b.name}: ${b.status}`).join("\n")}

4. E-FAC / SHELTER STATUS
${appData.efacs.map(e => `- ${e.name}: ${e.status}`).join("\n")}
${appData.shelters.map(s => `- ${s.name}: ${s.status}`).join("\n")}

5. COMMAND NOTES
- Verify all current incident data against official sources before operational use.
- Update resource status and contact points each operational period.
`;

  document.getElementById("sitrep").value = text.trim();
}

function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}
