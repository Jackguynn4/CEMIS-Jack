# Deployment Guide

## GitHub Pages

Upload the project files so this structure is visible in the repository root:

```text
index.html
README.md
css/
js/
data/
assets/
docs/
```

Then enable GitHub Pages from the repository settings.

## Data Persistence

This version saves data to browser local storage. For shared-team use, export JSON after updates and distribute/import the current JSON file.

A future version can connect to Firebase, Supabase, SharePoint, or a government-approved database.
