# Colorado EMIS COP v3.0

Colorado Emergency Management Intelligence System Common Operating Picture.

## What this is

A static web application that can be hosted on GitHub Pages and opened in a browser.

It includes:

- Interactive Colorado map
- Active/recent wildfire markers
- Military bases
- E-FAC points
- Shelters
- Points of interest
- Road closure markers
- Local browser saving
- Import/export JSON
- Export CSV
- SITREP generator

## How to run locally

1. Download or clone this folder.
2. Open `index.html` in a browser.

If the browser blocks some map features, use VS Code Live Server or run:

```bash
python -m http.server 8000
```

Then open:

```text
http://localhost:8000
```

## How to deploy on GitHub Pages

1. Create a GitHub repository.
2. Upload everything in this folder.
3. Make sure `index.html` is in the top/root level of the repository.
4. Go to Settings > Pages.
5. Select Deploy from branch.
6. Select branch `main` and folder `/root`.
7. Save.

## Important operational disclaimer

This is a planning and training prototype. Do not use this as the sole source for emergency decision-making.

Verify operational incident information against:

- NIFC
- InciWeb
- Colorado DFPC
- County EOCs
- Local command channels
- Official public safety alerts
