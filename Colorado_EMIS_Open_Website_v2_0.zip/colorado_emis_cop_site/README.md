# Colorado Emergency Management COP Website

Open `index.html` in a web browser.

## What it does
- Interactive Colorado map
- Add fires, shelters, bases, E-FACs, POIs, and road closures
- Toggle map layers
- Export/import your data as JSON
- Generate a basic SITREP text file
- Saves edits in browser local storage

## Important
This is a planning and demonstration tool. Verify all operational data with official sources such as NIFC, InciWeb, RMAC, NOAA/NWS, CDOT, and local emergency management before use.

## Data workflow
1. Open `index.html`.
2. Add/edit points with the top buttons.
3. Export Data at the end of each session.
4. Import the JSON later to continue working.

## Internet requirement
The map uses Leaflet and OpenStreetMap tiles from CDNs, so the map background needs internet access. Your entered data is stored locally in your browser and can be exported.
