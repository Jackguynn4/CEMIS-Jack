# Colorado EMIS COP v3.0

Open `index.html` in a browser. If live layers do not load from local file mode, use VS Code Live Server or host on GitHub Pages.

## Basic workflow
1. Open the site.
2. Add fires, bases, E-FACs, shelters, POIs, road closures, or evacuation zones using the left panel.
3. Save is automatic in your browser.
4. Use Export JSON to back up/share your operational data.
5. Use Import JSON to restore or load someone else's data.
6. Use Generate SITREP for a briefing-ready summary.

## Live data
The Load Live NIFC/WFIGS button attempts to query public ArcGIS REST feature services for current wildland fire data and filter to Colorado. If a browser blocks the federal service, use manual entry or import a verified GeoJSON/JSON dataset.

## Operational caution
This is a planning prototype. Verify active fire, evacuation, road, shelter, and resource status with official incident command, NIFC, InciWeb, RMACC, state/county emergency management, and local authorities before operational use.
