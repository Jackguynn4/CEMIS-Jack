# Data sources

Primary recommended official sources:
- National Interagency Fire Center maps and Wildland Fire Open Data
- WFIGS Current / 2026 Interagency Fire Perimeters
- InciWeb Colorado incident pages
- Colorado Division of Fire Prevention and Control
- County sheriff / emergency management updates

The live button includes candidate public ArcGIS REST endpoints and filters features to Colorado by state field or bounding box. Endpoints may change; verify before operational use.
